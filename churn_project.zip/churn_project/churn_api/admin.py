

# Register your models here.
from django.contrib import admin
# from .models import ChurnPrediction

# @admin.register(ChurnPrediction)
# class ChurnPredictionAdmin(admin.ModelAdmin):
#     list_display = ('id', 'churn_probability', 'predicted_at')
#     list_filter = ('predicted_at',)
#     ordering = ('-predicted_at',)

